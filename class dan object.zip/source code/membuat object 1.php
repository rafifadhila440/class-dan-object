<?php
class Coba{

}

$a = new Coba();
echo var_dump($a) . "<br>";

$b = new Coba();
echo var_dump($b) . "<br>";

$c = new Coba();
echo var_dump($c) . "<br>";

?>