<?php
class Coba{

}

//membuat object instance dari class
$a = new Coba();
$b = new Coba();
$c = new Coba();

?>