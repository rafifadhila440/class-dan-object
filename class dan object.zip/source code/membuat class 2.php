<?php
class Coba{
    public function b(){

    }

}

?>