<?php
class Coba{
    
}

?>